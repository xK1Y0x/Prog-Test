package org.example;
import java.util.Random;

public class Question_2 {
    public static void main

    {

        public static void main (String[]args){
        String[] strArr = new String[50];
    }
    }

    ii .

    public static void main(String[] args) {
        String[] strArr;
        strArr = new String[50];

    }

    iii .
            for ( int i = 0;)

}