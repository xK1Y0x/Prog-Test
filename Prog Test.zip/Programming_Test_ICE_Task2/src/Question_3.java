package org.example;
import java.util.Arrays;

public class main{
    public static void main(String [] args){

        int [] intArr = {10, 5, 20, 25, 29, 27, 22, 12, 8};
        for (int a = 0; a < intArr.length - 1; a++){
            for (int b = a; b < intArr.length - 1; b++){
                if( intArr[a] > intArr[b + 1])
                {
                    int temp = intArr[a];
                    int intArr[a] = intArr[b + 1];
                    int intArr[b + 1] = int temp;
                }
            System.out.println(String.toArray(intArr.length));
            }

        }
    }
}
