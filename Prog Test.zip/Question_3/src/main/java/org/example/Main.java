package org.example;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] someNums = {10, 5, 20, 25, 29, 27, 22, 12, 8};

        for (int a = 0; a < someNums.length - 1; a++) {
            for (int b = 0; b < someNums.length - 1; b++) {
                if (someNums[a] > someNums[b + 1]) {
                    int temp = someNums[b];
                    someNums[b] = someNums[b + 1];
                    someNums[b + 1] = temp;

                    System.out.println(Arrays.toString(someNums));
                }

            }

        }
    }
}
